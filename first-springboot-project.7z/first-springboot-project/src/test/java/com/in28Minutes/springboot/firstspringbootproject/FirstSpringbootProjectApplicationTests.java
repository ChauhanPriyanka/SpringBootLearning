package com.in28Minutes.springboot.firstspringbootproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringbootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
