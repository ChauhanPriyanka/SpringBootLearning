package com.in28Minutes.springboot;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.in28Minutes.springboot.configuration.BasicConfiguration;

@RestController
public class WelcomeController {

	@Autowired
	private WelcomeService welcomeService;
	
	@Autowired
	private BasicConfiguration basicConfig;
	
	@RequestMapping("/welcome")
	public String showMessgae() {
		return welcomeService.retrieveWelocmeMessage();
	}
	
	@RequestMapping("/dynamic-configuration")
	public Map dynamicConfiguration() {
		Map mp = new HashMap();
		mp.put("message", basicConfig.getMessage());
		mp.put("number", basicConfig.isValue());
		mp.put("value", basicConfig.getNumber());
		return mp;
	}
}

@Component
class WelcomeService
{
	@Value("${welcome.message}")
	public String welcomeMessage;
	public String retrieveWelocmeMessage() {
		return welcomeMessage;
	}
}