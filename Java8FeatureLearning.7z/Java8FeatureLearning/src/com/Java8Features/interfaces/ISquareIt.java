package com.Java8Features.interfaces;

public interface ISquareIt {

	public int square(int a);
}
