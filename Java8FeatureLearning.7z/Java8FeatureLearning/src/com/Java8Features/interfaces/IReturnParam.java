package com.Java8Features.interfaces;

public interface IReturnParam {
public int getLength(String s);
}
