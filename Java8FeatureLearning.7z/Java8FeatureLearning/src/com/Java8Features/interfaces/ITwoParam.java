package com.Java8Features.interfaces;

public interface ITwoParam {

	public void add(int a, int b);
}
