package com.Java8Features.interfaces;

public interface IZeroParam {
public void m1();
}
class Demo implements IZeroParam
{

	@Override
	public void m1() {
		// TODO Auto-generated method
		System.out.println("m1 method implementation");
	}
	
}