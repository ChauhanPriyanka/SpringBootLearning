package com.Java8Features.Bean;

import java.util.ArrayList;

public class Student {

	String name;
	int marks;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Student(String name, int marks) {
		super();
		this.name = name;
		this.marks = marks;
	}
	
	public static void populate(ArrayList<Student> l)
	{
		l.add(new Student("Sunny", 100));
		l.add(new Student("Bunny", 65));
		l.add(new Student("Chunny", 100));
		l.add(new Student("Vinny", 55));
		l.add(new Student("Pinny", 45));
	}
}
