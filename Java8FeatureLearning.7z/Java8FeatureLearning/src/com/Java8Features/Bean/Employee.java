package com.Java8Features.Bean;

public class Employee {

	public String name;
	public Integer eno;
	public String city;
	public 	String designation;
	public double Salary;
	
	public Employee(String name, String city, String designation, double salary) {
		super();
		this.name = name;
		this.city = city;
		this.designation = designation;
		Salary = salary;
	}
	
	//this is for other example
	public Employee(String name, Integer eno) {
		super();
		this.name = name;
		this.eno = eno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getEno() {
		return eno;
	}
	public void setEno(Integer eno) {
		this.eno = eno;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", eno=" + eno + ", city=" + city + ", designation=" + designation
				+ ", Salary=" + Salary + "]";
	}
	
	
}
