package com.Java8Features;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

import com.Java8Features.Bean.Employee;
import com.Java8Features.Bean.Student;
import com.Java8Features.interfaces.IReturnParam;
import com.Java8Features.interfaces.ISquareIt;
import com.Java8Features.interfaces.ITwoParam;
import com.Java8Features.interfaces.IZeroParam;

public class Main {
	
	public static void demoArrayList() {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(10);
		al.add(12);
		al.add(0);
		al.add(2);
		al.add(1);
		System.out.println("The arraylist is"+al);
		System.out.println("after sorting................");
		al.sort((I1,I2)->(I1>I2) ? -1 : (I1<I2) ? 1 : 0 ); //sorting in descending order
		System.out.println("The arraylist is"+al);
	}
	
	public static void demoTreeSet() {
		//by default tree set is already in sorted order
		// it does not maintain the insertion order
		//TreeSet<Integer> t = new TreeSet<Integer>();
		TreeSet<Integer> t = new TreeSet<Integer>((I1,I2)->(I1>I2) ? -1 : (I1<I2) ? 1 : 0);
		t.add(10);
		t.add(12);
		t.add(0);
		t.add(2);
		t.add(1);
		System.out.println("The treeset is"+t);
	}
	
	public static void demoTreeMap() {
		//by default tree map is already in sorted using key
		// it does not maintain the insertion order
		//TreeSet<Integer> t = new TreeSet<Integer>();
		TreeMap<Integer,String> t = new TreeMap<Integer,String>((I1,I2)->(I1>I2) ? -1 : (I1<I2) ? 1 : 0);
		t.put(1,"Akhilesh");
		t.put(2, "Priyanka");
		
		System.out.println("The treeMap is"+t);
	}
	
	public static void m1(Predicate<Integer> p, int[] x)
	{
		for(int i:x)
		{
			if(p.test(i)) {
				System.out.println("The number is" + i);
			}
		}
	}
	
	public static void DisplayEmployee(Predicate<Employee> p, ArrayList<Employee> employeeList)
	{
		for(Employee e:employeeList)
		{
			if(p.test(e)) {
				System.out.println(e);
			}
		}
	}
	
	public static void main(String[] args) {
		//Before lambda expression
		IZeroParam i2 = new Demo();
		i2.m1();
		
		IZeroParam i1 = ()->System.out.println("***lambda method implementation");
		
		i1.m1();
		
		ITwoParam interfaceTwoParam = (a,b)->System.out.println("Sum is "+ (a+b));
		interfaceTwoParam.add(10, 20);
		interfaceTwoParam.add(100, 200);
		
		IReturnParam interfaceReturnParam = (s)->s.length();
		System.out.println("Using Lambda expression  is"+interfaceReturnParam.getLength("hello"));
		System.out.println("Using Lambda expression is"+interfaceReturnParam.getLength("Priyanka C"));
		
		ISquareIt interfaceSquare = x->(x*x);
		System.out.println("Using lambda expression"+ interfaceSquare.square(8));
		
		
		//Runnable interface demo
		//Runnable r = new DemoRunnable();
		Runnable r = ()-> {
			for(int i = 0; i<10;i++)
				System.out.println("Using lambda expression, child..");
		};
		Thread t = new Thread(r);
		t.start();
		for(int i = 0; i<10; i++)
		{
			System.out.println("Main thread");
		}
		
		//collection in lambda
		demoArrayList();
		demoTreeSet();
		demoTreeMap();
		
		//lambdaInUserDefinedObject
		ArrayList<Employee> el = new ArrayList<Employee>();
		el.add(new Employee("Akhilesh",1));
		el.add(new Employee("Priyanka",2));
		el.sort((e1,e2)->(e1.eno > e2.eno)? -1 : (e1.eno < e2.eno) ? 1 : 0);
		System.out.println("Employee are"+el);
			
		Predicate<Integer> p = I->I>10;
		System.out.println("Check if 100 is greater than 10"+p.test(100));
		System.out.println("Check if 5 is greater than 10"+p.test(5));
		
		Predicate<Collection> p1 = c-> (c.isEmpty());
		ArrayList<String> aList = new ArrayList<String>();
		System.out.println("Is EMpty()"+ p1.test(aList));
		
		
		//Predicate default method: negate and and or
		int[] x = {0,5,10,15,20,25,30};
		Predicate<Integer> p2 = c->c>10;
		Predicate<Integer> p3 = c->c%2 == 0;
		System.out.println("The no. greater than 10 are");
		m1(p2,x);
		System.out.println("even number are");
		m1(p3,x);
		System.out.println("Negate of predicate 2 are");
		m1(p2.negate(),x);
		System.out.println("And of predicate are ");
		m1(p2.and(p3),x);
		System.out.println("OR of predicate are ");
		m1(p2.or(p3),x);
		
		
		//name starts with k;
		String[] name = {"sunny", "kajol", "mallika", "katrina", "karrena"};
		Predicate<String> startsWithK = s-> s.charAt(0) == 'k';
		for(String s: name)
		{
			if(startsWithK.test(s)) {
				System.out.println("Name is"+ s);
			}
		}
		
		ArrayList<Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee("Durga", "Hyderabad", "CEO", 30000));
		employees.add(new Employee("Sunny", "Banglore", "Manager", 20000));
		employees.add(new Employee("Kareena", "Delhi", "Manager", 30000));
		employees.add(new Employee("Katreena", "Bhopal", "CEO", 20000));
		employees.add(new Employee("Mallika", "Bombay", "CEO", 10000));
		employees.add(new Employee("Ramya", "Banglore", "Actor", 15000));
		System.out.println(employees);
		
		Predicate<Employee> p4 = emp->emp.designation.equals("Manager");
		System.out.println("Select the employe which are manager");
		DisplayEmployee(p4, employees);
		
		Predicate<Employee> p5 = emp->emp.city.equals("Banglore");
		System.out.println("Select the employe which are Banglore");
		DisplayEmployee(p5, employees);
		
		Predicate<Employee> p6 = emp->emp.Salary<20000;
		System.out.println("Select the employe whose salary are less than 20000");
		DisplayEmployee(p6, employees);
		
		System.out.println("Select the employe who are manager and from blore");
		DisplayEmployee(p4.and(p5), employees);
		
		System.out.println("Select the employe who are manager or salary less than 20000");
		DisplayEmployee(p4.or(p5), employees);
		
		System.out.println("Select the employe who are not manager");
		DisplayEmployee(p4.negate(), employees);
		
		//Function Interface
		Function<String, Integer> f1 = s->s.length();
		System.out.println("Function Interface find the string length "+f1.apply("Priyanka"));
		
		Function<Integer, Integer> f2 = I->I*I;
		System.out.println("Function Interface find the square "+f2.apply(5));
		
		//program to remove spaces in given string
		Function<String, String> f3 = s->s.replaceAll(" ", "");
		System.out.println("Remove spaces from string "+f3.apply("Durga Soft Solution Hyderabad"));
		
		//Function Interface
		Function<String, Integer> f4 = s->s.length()-s.replaceAll(" ", "").length();
		System.out.println("Function Interface find the spaces in the string= "+f4.apply("Durga Soft Solution Hyderabad"));

		ArrayList<Student> sl = new ArrayList<Student>();
		Student.populate(sl);
		Function<Student, String> f5 = s->{
			int marks = s.getMarks();
			if(marks  >= 80)
				return "A Distiction";
			else if(marks  >= 60)
				return "B First";
			else if(marks  >= 50)
				return "C Second";
			else if(marks  >= 35)
				return "D Third";
			else if(marks <35)
				return "E Fail";
			return null;
		};
		
		//Predicate and function together
		Predicate<Student> p7 = s-> s.getMarks() >= 60;	
		for(Student s : sl)
		{
			if(p7.test(s))
				System.out.println("Name :" + s.getName() + " Marks: " + s.getMarks() + " Grade: " + f5.apply(s));
		}
	
		//find the total salary pf all employe
		Function<ArrayList<Employee>, Double> f6 = l->{
			Double salary=(double) 0;
			for(Employee e : employees)
			{
				salary=salary+e.Salary;
			}
			return salary;
		};
		System.out.println("Total salary of employees" + f6.apply(employees));
		
		//this is the consumer funtion interface
		Consumer<String> c1 = s->System.out.println(s);
		c1.accept("Hello this is consumer functional interface demo");
		
		Consumer<Student> c2 = s-> System.out.println("Name :" + s.getName() + " Marks: " + s.getMarks() + " Grade: " + f5.apply(s));
		for(Student s : sl)
		{
			c2.accept(s);
		}
		
		
		//Bipredicate
		//Check if the return number is even or odd
		BiPredicate<Integer, Integer> bp = (a,b) -> (a+b)%2 ==0;
		System.out.println("Bi Predicate sum of two integer numbers are " +bp.test(10,20));
		
		//bifunction produc to two numbers
		BiFunction<Integer, Integer, Integer> bf = (a,b) -> (a*b);
		System.out.println("Bifunction product of two integer numbers are " +bf.apply(10, 20));
		
		//create student object by taking name and roll number as the input parametr
	    ArrayList<Student> listStu = new ArrayList<Student>();
		BiFunction<String, Integer, Student> bf1 = (name1, rollnumber) -> new Student(name1, rollnumber);
		listStu.add(bf1.apply("Durga", 100));
		listStu.add(bf1.apply("Ravi", 200));
		listStu.add(bf1.apply("Mohan", 300));
		for(Student s : listStu)
		{
			c2.accept(s);
		}
	}
	
	
}


class Demo implements IZeroParam
{

	@Override
	public void m1() {
		// TODO Auto-generated method
		System.out.println("m1 method implementation");
	}
	
}