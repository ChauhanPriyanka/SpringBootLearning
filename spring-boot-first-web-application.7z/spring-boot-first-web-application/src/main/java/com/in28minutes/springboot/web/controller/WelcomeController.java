package com.in28minutes.springboot.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
//@SessionAttributes("name") : name will be added from security login.
//both the ways are fine to store user name in session and in attributes.
public class WelcomeController {

	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showWelcomePage( ModelMap model){
		//model.put("name", name);
		//System.out.println("Name is"+name);
		String name = getLoggedinUserName();
		model.put("name", getLoggedinUserName());
		return "welcome";
	}
	
	private String getLoggedinUserName() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			return ((UserDetails)principal).getUsername();
		}
		return principal.toString();
	}
//	Removed login controller as part of spring security demo
//	@RequestMapping(value = "/login", method = RequestMethod.POST)
//	public String showWelcomeMessage( ModelMap model, @RequestParam String name, @RequestParam String password){
//		boolean bIsValid =  service.validateUser(name, password);
//		if(!bIsValid) {
//			model.put("message", "Invalid Crenditials");
//			return "login";
//		}
//		
//		model.put("name", name);
//		model.put("password", password);
//		//System.out.println("Name is"+name);
//		return "welcome";
//	}
}
