package com.learning.jpa.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.learning.jpa.entity.User;

@Repository
//@Repository is something which interacts with database.
@Transactional
//each method will be involved in transaction
public class UserDAOService {

	
	/*
	 * User jack = new User("jack", "admin");
	 * User jill = new User("jill", "admin");
	 * entityManager.persist(jack);
	 * Here comes the concept of Persistent context.
	 * Entity manager will track only object(Jack) which are persistent and it will not track Jill here
	 * */
	@PersistenceContext
	private EntityManager entityManager;
	
	public long	insert(User user) {
		entityManager.persist(user);
		return user.getId();
	}
}
